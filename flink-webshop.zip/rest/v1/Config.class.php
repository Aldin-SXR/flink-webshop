<?php
class Config {
    const DB = array(
		"host" => "127.0.0.1",
		"db" => "flink-webshop",
		"user" => "root",
		"pass" => "tanzmitmir1488",
		"charset" => "utf8mb4"
	);
	const JWT_SECRET = "e+ktaj/G?2dPJf;9X";
}
?>